#include "GLWidget.h"
#include <QApplication>
#include "transparencysliders.h"
#include <iostream>
#include <QHBoxLayout>
#include <QWidget>
#include <transfer.h>
#include <thread>
#include <pthread.h>

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <queue>
using namespace std;
std::queue<char *> IndexValues;
std::vector<Vec4f> TfValues;

//GLWidget w;

pthread_mutex_t myMutex;

void error(const char *msg)
{
    perror(msg);
    exit(0);
}

// Data is of the form 1,0.5,03,1 rgba. Want to convert to Vec4f<float()>
Vec4f parseData(string str)
{
    float r,g,b,a;
    std::string delimiter = ",";

    size_t pos = 0;

int i=0;
    bool flag =true;
//float Vectors[3]={0,0,0};
    while ((pos = str.find(delimiter)) != std::string::npos) {
        if (flag){
        r = stof(str.substr(1, pos-1));
        flag =false;
        }else if(i==1)
        {
            g = stof(str.substr(0, pos));
        }else
        {
            b = stof(str.substr(0, pos));
        }
//        float Vectors[i]=st/*d*/::stof(token);
//        std::cout << token << std::endl;
        str.erase(0, pos + delimiter.length());
        i=i+1;
    }
//    cout<<" "<<r<<" "<<g<<" "<<b<<" ";
return Vec4f(r,g,b,float(1));
}





void *getValuesFromViews(void *threadid)
{
//   long tid;
//   tid = (long)threadid;
   GLWidget* W=(GLWidget *)threadid;

   int sockfd, portno, n;
   struct sockaddr_in serv_addr;
   struct hostent *server;

   char buffer[4096];
   portno = 5001;
   sockfd = socket(AF_INET, SOCK_STREAM, 0);
   if (sockfd < 0)
       error("ERROR opening socket");

   server = gethostbyname("127.0.0.1");
   if (server == NULL) {
       fprintf(stderr,"ERROR, no such host\n");
       exit(0);
   }
   bzero((char *) &serv_addr, sizeof(serv_addr));
   serv_addr.sin_family = AF_INET;
   bcopy((char *)server->h_addr,
        (char *)&serv_addr.sin_addr.s_addr,
        server->h_length);
   serv_addr.sin_port = htons(portno);
   if (connect(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
       error("ERROR connecting");
    cout<<"socket opened";

   // Logic for handling queues !!!
    std::string BufferString;
    TfValues.clear();

    while(1){

       n = read(sockfd, buffer, 4096);
       BufferString = std::string(buffer);
       std::remove(BufferString.begin(), BufferString.end(), ' ');

       if (!BufferString.empty())
        {
//           cout<<BufferString<< " ";
            // critical section
//            pthread_mutex_lock(&myMutex);

            TfValues.push_back(parseData(BufferString));

//            TfValues.push(parseData(BufferString));
            pthread_mutex_unlock(&myMutex);

//            cout<<"Size"<<TfValues.size();
           if (n < 0)
               continue;

           if (TfValues.size() == 27)
            {
//               cout<<TfValues.size();
               W->changeInOtherViews(TfValues);
               bzero(buffer,4096);
               TfValues.clear();
            }
        }
    }
   pthread_exit(NULL);
}

int main(int argc, char *argv[])
{

    pthread_t threads;

    QApplication a(argc, argv);
    GLWidget w;

    transparencySliders Slider;

    Transfer Yes;
//// Showing just for demonstration nothing else
//    int rc = pthread_create(&threads, NULL,getValuesFromViews,(void *)&w);
//          if (rc){
//             cout << "Error:unable to create thread," << rc << endl;
//             exit(-1);
//          }    QGLFormat glFormat = QGLFormat::defaultFormat();


//    glFormat.setVersion(3, 3);
//    glFormat.setProfile(QGLFormat::CoreProfile);
//    glFormat.setSampleBuffers(true);
//    glFormat.setSamples(4);
//    QGLFormat::setDefaultFormat(glFormat);

    Yes.acceptGLWidget(&w);
    Yes.show();

//  QT widget integration
    Slider.acceptGLWidget(&w,&Yes);

//    cout<< IndexValues.front()<<"VAlue in main progra,";
    QWidget *window1 = new QWidget();
    QWidget *window2 = new QWidget();

    QHBoxLayout *layout1 = new QHBoxLayout();
    QHBoxLayout *layout2 = new QHBoxLayout();


    // Reducing the size of 2
    layout1->addWidget(&w);
    window1->setLayout(layout1);
    QSizePolicy spLeft(QSizePolicy::Preferred, QSizePolicy::Preferred);
    spLeft.setHorizontalStretch(2);
    window1->setSizePolicy(spLeft);

    layout2->addWidget(&Slider);
    window2->setLayout(layout2);

    QSizePolicy spRight(QSizePolicy::Preferred, QSizePolicy::Preferred);
    spRight.setHorizontalStretch(1);
    window2->setSizePolicy(spRight);

    QHBoxLayout *layout = new QHBoxLayout();
    QWidget *window = new QWidget();

    layout->addWidget(window1);
    layout->addWidget(window2);


    window->setLayout(layout);
    window->setMinimumSize(1100,700);
    window->show();

//    close(sockfd);

    return a.exec();


}




