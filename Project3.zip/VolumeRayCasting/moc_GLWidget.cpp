/****************************************************************************
** Meta object code from reading C++ file 'GLWidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "GLWidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'GLWidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_GLWidget_t {
    QByteArrayData data[55];
    char stringdata[767];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GLWidget_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GLWidget_t qt_meta_stringdata_GLWidget = {
    {
QT_MOC_LITERAL(0, 0, 8),
QT_MOC_LITERAL(1, 9, 13),
QT_MOC_LITERAL(2, 23, 0),
QT_MOC_LITERAL(3, 24, 13),
QT_MOC_LITERAL(4, 38, 14),
QT_MOC_LITERAL(5, 53, 14),
QT_MOC_LITERAL(6, 68, 15),
QT_MOC_LITERAL(7, 84, 16),
QT_MOC_LITERAL(8, 101, 18),
QT_MOC_LITERAL(9, 120, 22),
QT_MOC_LITERAL(10, 143, 20),
QT_MOC_LITERAL(11, 164, 14),
QT_MOC_LITERAL(12, 179, 19),
QT_MOC_LITERAL(13, 199, 7),
QT_MOC_LITERAL(14, 207, 19),
QT_MOC_LITERAL(15, 227, 11),
QT_MOC_LITERAL(16, 239, 19),
QT_MOC_LITERAL(17, 259, 11),
QT_MOC_LITERAL(18, 271, 5),
QT_MOC_LITERAL(19, 277, 3),
QT_MOC_LITERAL(20, 281, 16),
QT_MOC_LITERAL(21, 298, 17),
QT_MOC_LITERAL(22, 316, 18),
QT_MOC_LITERAL(23, 335, 19),
QT_MOC_LITERAL(24, 355, 16),
QT_MOC_LITERAL(25, 372, 17),
QT_MOC_LITERAL(26, 390, 16),
QT_MOC_LITERAL(27, 407, 17),
QT_MOC_LITERAL(28, 425, 11),
QT_MOC_LITERAL(29, 437, 13),
QT_MOC_LITERAL(30, 451, 14),
QT_MOC_LITERAL(31, 466, 12),
QT_MOC_LITERAL(32, 479, 17),
QT_MOC_LITERAL(33, 497, 8),
QT_MOC_LITERAL(34, 506, 21),
QT_MOC_LITERAL(35, 528, 16),
QT_MOC_LITERAL(36, 545, 13),
QT_MOC_LITERAL(37, 559, 13),
QT_MOC_LITERAL(38, 573, 5),
QT_MOC_LITERAL(39, 579, 14),
QT_MOC_LITERAL(40, 594, 6),
QT_MOC_LITERAL(41, 601, 1),
QT_MOC_LITERAL(42, 603, 5),
QT_MOC_LITERAL(43, 609, 16),
QT_MOC_LITERAL(44, 626, 8),
QT_MOC_LITERAL(45, 635, 4),
QT_MOC_LITERAL(46, 640, 14),
QT_MOC_LITERAL(47, 655, 28),
QT_MOC_LITERAL(48, 684, 23),
QT_MOC_LITERAL(49, 708, 17),
QT_MOC_LITERAL(50, 726, 20),
QT_MOC_LITERAL(51, 747, 13),
QT_MOC_LITERAL(52, 761, 1),
QT_MOC_LITERAL(53, 763, 1),
QT_MOC_LITERAL(54, 765, 1)
    },
    "GLWidget\0changeDensity\0\0changeDiffuse\0"
    "changeAmbience\0changeSpecular\0"
    "changeBrighness\0changeSampleRate\0"
    "changeTransparency\0ChangeTransferFunction\0"
    "InitializeParameters\0InitializeRect\0"
    "std::vector<Vec2f>&\0vertice\0"
    "GLArrayBuffer::Ptr&\0ArrayBuffer\0"
    "GLVertexArray::Ptr&\0VertexArray\0Start\0"
    "End\0changeSliceXleft\0changeSliceXright\0"
    "changeInOtherViews\0std::vector<Vec4f>&\0"
    "changeSliceYleft\0changeSliceYright\0"
    "changeSliceZleft\0changeSliceZright\0"
    "changeShine\0checkSnapshot\0PreIntegration\0"
    "preIntegrate\0getTransferValues\0transfer\0"
    "checkAmbientOcclusion\0AmbientOcclusion\0"
    "checkAmbience\0checkSpecular\0split\0"
    "vector<string>\0string\0s\0delim\0"
    "checkBoundingBox\0changeTF\0Path\0"
    "checkDiffusion\0ChangeTransferFunctionThread\0"
    "ChangeTransferFunction2\0changeRayStepSize\0"
    "changeTransferOffset\0changeDataset\0x\0"
    "y\0z"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GLWidget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      35,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  189,    2, 0x0a /* Public */,
       3,    1,  192,    2, 0x0a /* Public */,
       4,    1,  195,    2, 0x0a /* Public */,
       5,    1,  198,    2, 0x0a /* Public */,
       6,    1,  201,    2, 0x0a /* Public */,
       7,    1,  204,    2, 0x0a /* Public */,
       8,    1,  207,    2, 0x0a /* Public */,
       9,    0,  210,    2, 0x0a /* Public */,
      10,    0,  211,    2, 0x0a /* Public */,
      11,    5,  212,    2, 0x0a /* Public */,
      20,    1,  223,    2, 0x0a /* Public */,
      21,    1,  226,    2, 0x0a /* Public */,
      22,    1,  229,    2, 0x0a /* Public */,
      24,    1,  232,    2, 0x0a /* Public */,
      25,    1,  235,    2, 0x0a /* Public */,
      26,    1,  238,    2, 0x0a /* Public */,
      27,    1,  241,    2, 0x0a /* Public */,
      28,    1,  244,    2, 0x0a /* Public */,
      29,    0,  247,    2, 0x0a /* Public */,
      30,    1,  248,    2, 0x0a /* Public */,
      31,    0,  251,    2, 0x0a /* Public */,
      32,    1,  252,    2, 0x0a /* Public */,
      34,    1,  255,    2, 0x0a /* Public */,
      35,    0,  258,    2, 0x0a /* Public */,
      36,    1,  259,    2, 0x0a /* Public */,
      37,    1,  262,    2, 0x0a /* Public */,
      38,    2,  265,    2, 0x0a /* Public */,
      43,    1,  270,    2, 0x0a /* Public */,
      44,    1,  273,    2, 0x0a /* Public */,
      46,    1,  276,    2, 0x0a /* Public */,
      47,    0,  279,    2, 0x0a /* Public */,
      48,    0,  280,    2, 0x0a /* Public */,
      49,    1,  281,    2, 0x0a /* Public */,
      50,    1,  284,    2, 0x0a /* Public */,
      51,    4,  287,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 12, 0x80000000 | 14, 0x80000000 | 16, QMetaType::Float, QMetaType::Float,   13,   15,   17,   18,   19,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, 0x80000000 | 23,   13,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 23,   33,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    0x80000000 | 39, 0x80000000 | 40, QMetaType::Char,   41,   42,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, 0x80000000 | 40,   45,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, 0x80000000 | 40, 0x80000000 | 40, 0x80000000 | 40, 0x80000000 | 40,   45,   52,   53,   54,

       0        // eod
};

void GLWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        GLWidget *_t = static_cast<GLWidget *>(_o);
        switch (_id) {
        case 0: _t->changeDensity((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->changeDiffuse((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->changeAmbience((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->changeSpecular((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->changeBrighness((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->changeSampleRate((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->changeTransparency((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->ChangeTransferFunction(); break;
        case 8: _t->InitializeParameters(); break;
        case 9: _t->InitializeRect((*reinterpret_cast< std::vector<Vec2f>(*)>(_a[1])),(*reinterpret_cast< GLArrayBuffer::Ptr(*)>(_a[2])),(*reinterpret_cast< GLVertexArray::Ptr(*)>(_a[3])),(*reinterpret_cast< float(*)>(_a[4])),(*reinterpret_cast< float(*)>(_a[5]))); break;
        case 10: _t->changeSliceXleft((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->changeSliceXright((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: _t->changeInOtherViews((*reinterpret_cast< std::vector<Vec4f>(*)>(_a[1]))); break;
        case 13: _t->changeSliceYleft((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->changeSliceYright((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->changeSliceZleft((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->changeSliceZright((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: _t->changeShine((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->checkSnapshot(); break;
        case 19: _t->PreIntegration((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 20: _t->preIntegrate(); break;
        case 21: _t->getTransferValues((*reinterpret_cast< std::vector<Vec4f>(*)>(_a[1]))); break;
        case 22: _t->checkAmbientOcclusion((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 23: _t->AmbientOcclusion(); break;
        case 24: _t->checkAmbience((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 25: _t->checkSpecular((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 26: { vector<string> _r = _t->split((*reinterpret_cast< const string(*)>(_a[1])),(*reinterpret_cast< char(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< vector<string>*>(_a[0]) = _r; }  break;
        case 27: _t->checkBoundingBox((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 28: _t->changeTF((*reinterpret_cast< string(*)>(_a[1]))); break;
        case 29: _t->checkDiffusion((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 30: _t->ChangeTransferFunctionThread(); break;
        case 31: _t->ChangeTransferFunction2(); break;
        case 32: _t->changeRayStepSize((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 33: _t->changeTransferOffset((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 34: _t->changeDataset((*reinterpret_cast< string(*)>(_a[1])),(*reinterpret_cast< string(*)>(_a[2])),(*reinterpret_cast< string(*)>(_a[3])),(*reinterpret_cast< string(*)>(_a[4]))); break;
        default: ;
        }
    }
}

const QMetaObject GLWidget::staticMetaObject = {
    { &QGLWidget::staticMetaObject, qt_meta_stringdata_GLWidget.data,
      qt_meta_data_GLWidget,  qt_static_metacall, 0, 0}
};


const QMetaObject *GLWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GLWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_GLWidget.stringdata))
        return static_cast<void*>(const_cast< GLWidget*>(this));
    return QGLWidget::qt_metacast(_clname);
}

int GLWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QGLWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 35)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 35;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 35)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 35;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
