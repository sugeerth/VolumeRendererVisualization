1) Change the dataset file location to the one you want by changing the locaiton in line no.35 in GLWidget.cpp file 
2) Alternativly , you could goto the dataset panel and then choose the dataset as well as the dimensions using QFILEDIALOGUE of qt . 
3) Ability to use the snapshot tool, provides you the intermediate values for providing a great picture 
4) Any comments about the tool would be helpful 
