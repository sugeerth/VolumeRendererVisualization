#include "transparencysliders.h"
#include "ui_transparencysliders.h"
#include <QFileDialog>
#include<QMessageBox>
#include "GLWidget.h"
#include<iostream>
using namespace std;

transparencySliders::transparencySliders(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::transparencySliders)
{
    ui->setupUi(this);
}

void transparencySliders::acceptGLWidget(GLWidget *w)
{
    W=w;
    cout<<"TransparencySliders";


    connect(ui->AmbientLightSLider,SIGNAL(valueChanged(int)),w,SLOT(changeAmbience(int)));
    connect(ui->SpecularLightSlider,SIGNAL(valueChanged(int)),w,SLOT(changeSpecular(int)));

    connect(ui->DensitySlider,SIGNAL(valueChanged(int)),w,SLOT(changeDensity(int)));
    connect(ui->DiffuseSlider,SIGNAL(valueChanged(int)),w,SLOT(changeDiffuse(int)));
    connect(ui->BrightnessSlider,SIGNAL(valueChanged(int)),w,SLOT(changeTransparency(int)));
    connect(ui->shineSlider,SIGNAL(valueChanged(int)),w,SLOT(changeShine(int)));

    connect(ui->SamplingRateSlider,SIGNAL(valueChanged(int)),w,SLOT(changeSampleRate(int)));
    connect(ui->TransprencySlider,SIGNAL(valueChanged(int)),w,SLOT(changeTransparency(int)));

    connect(ui->DiffuseCheckbox,SIGNAL(clicked(bool)),w,SLOT(checkDiffusion(bool)));
    connect(ui->AmbientCheckbox,SIGNAL(clicked(bool)),w,SLOT(checkAmbience(bool)));
    connect(ui->SpeculaCheckbox,SIGNAL(clicked(bool)),w,SLOT(checkSpecular(bool)));

    connect(ui->TransferOffset,SIGNAL(valueChanged(int)),w,SLOT(changeTransferOffset(int)));
    connect(ui->Snapshot,SIGNAL(clicked()),w,SLOT(checkSnapshot()));
//    connect(ui->Dataset_Path,SIGNAL(),w,SLOT(checkSnapshot()));


}

transparencySliders::~transparencySliders()
{
    delete ui;
}

void transparencySliders::on_pushButton_clicked()
{
    QString filename = QFileDialog::getOpenFileName(
                this,tr("Open File"),"C://","All Files (*.*);;Text File (*.txt)");

    ui->TransferFunctionPAth->setText(filename);

//    QMessageBox::information(this,tr("File name"),filename);
}

void transparencySliders::on_pushButton_9_clicked()
{

    QString filename = QFileDialog::getOpenFileName(
                this,tr("Open File"),"C://","Raw File (*.raw);;All Files (*.*)");

    ui->Dataset_Path->setText(filename);

}


void transparencySliders::on_OKButtonDataset_clicked()
{

    cout<<"sfdsdf"<<endl;

    string Path = ui->Dataset_Path->toPlainText().toLocal8Bit().constData();
    string X = ui->x->toPlainText().toLocal8Bit().constData();
    string Y = ui->y->toPlainText().toLocal8Bit().constData();
    string Z = ui->z->toPlainText().toLocal8Bit().constData();

    W->changeDataset(Path,X,Y,Z);

    cout<<Path<<X<<Y<<Z;

}
