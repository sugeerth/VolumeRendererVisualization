#include "transferfunction.h"
#include "ui_transferfunction.h"

TransferFunction::TransferFunction(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::TransferFunction)
{
    ui->setupUi(this);
}

TransferFunction::~TransferFunction()
{
    delete ui;
}
