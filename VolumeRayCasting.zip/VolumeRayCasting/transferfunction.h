#ifndef TRANSFERFUNCTION_H
#define TRANSFERFUNCTION_H

#include <QWidget>
#include "GLWidget.h"
namespace Ui {
class TransferFunction;
}

class TransferFunction : public QWidget
{
    Q_OBJECT

public:
    explicit TransferFunction(QWidget *parent = 0);
    ~TransferFunction();
    GLWidget W;
private:
    Ui::TransferFunction *ui;
};

#endif // TRANSFERFUNCTION_H
