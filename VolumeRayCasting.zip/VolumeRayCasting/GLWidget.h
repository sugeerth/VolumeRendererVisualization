#ifndef GL_WIDGET_H
#define GL_WIDGET_H

#include "GLArrayBuffer.h"
#include "GLShaderProgram.h"
#include "GLTexture.h"
#include "GLVertexArray.h"
#include "Mat.h"
#include "Vec.h"
#include <QApplication>
#include <QDir>
#include <QFileDialog>
#include <QGLWidget>
#include <QMenu>
#include <QMenuBar>
#include <QMouseEvent>
#include <QGLWidget>
#include <QDebug>
#include <fstream>
#include <vector>
#include<iostream>
using namespace std;

class GLWidget : public QGLWidget
{
    Q_OBJECT

public:
    GLWidget(const QGLFormat &format = QGLFormat::defaultFormat(), QWidget *parent = 0);

protected:
    virtual void initializeGL();
    virtual void resizeGL(int w, int h);
    virtual void paintGL();
    virtual void Dataset(string, string,string,string);
    virtual void mouseMoveEvent(QMouseEvent *event);
    virtual void mousePressEvent(QMouseEvent *event);
    virtual void mouseReleaseEvent(QMouseEvent *event);
    virtual void wheelEvent(QWheelEvent *event);
    virtual void getIntermediateValues();
public slots:
    virtual void changeDensity(int);
    virtual void changeDiffuse(int);
    virtual void changeAmbience(int);
    virtual void changeSpecular(int);
    virtual void changeBrighness(int);
    virtual void changeSampleRate(int);
    virtual void changeTransparency(int);
//    virtual void changeDataSet(char *);
    virtual void changeShine(int);

    virtual void checkSnapshot();
    virtual void checkAmbience(bool);
    virtual void checkSpecular(bool);
    virtual void checkDiffusion(bool);
    virtual void changeTransferOffset(int);
    virtual void changeDataset(string Path,string x,string y,string z);

protected:
    QPointF mousePos;
    Mat3f rotation;
    Vec3f translation;
    Mat4f modelViewMatrix;
    Mat4f projectionMatrix;
    float StepSize;
    float Brightness;
    float Density;
    float offset;
    float Shininess;
    float DiffuseContribution;
    float DiffuseContributionOld;
    float SpecularContributionOld;
    float AmbienceCoefficientOld;
    float AmbienceCoefficient;
    float transferScale;
    float SpecularContribution;
    float SamplingRate;
    float transparency;
    float transferOffset;

    Vec3i volumeDim;
    GLTexture::Ptr volumeTex;
    GLTexture::Ptr transferFuncTex;
    GLArrayBuffer::Ptr rectVertexBuffer;
    GLArrayBuffer::Ptr rectIndexBuffer;
    GLVertexArray::Ptr rectVertexArray;
    GLShaderProgram::Ptr volumeRayCastingProgram;
};

#endif // GLWIDGET_H
