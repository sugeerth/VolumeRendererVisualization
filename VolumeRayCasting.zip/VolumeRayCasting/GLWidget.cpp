#include "GLWidget.h"
#include <QDebug>
#include <fstream>
#include <vector>
#include<iostream>
#include <fstream>
//#include<glew/>
#include <GL/glut.h>
#include <GL/glu.h>
#include <GL/gl.h>

using namespace std;

GLWidget::GLWidget(const QGLFormat &format, QWidget *parent) :
    QGLWidget(format, parent)
{
;

    setFocusPolicy(Qt::ClickFocus);
    setMinimumSize(256, 256);
//    cout<<"Asda";
    setWindowTitle("Volume Ray-casting");
}


void GLWidget::initializeGL()
{
#ifndef __APPLE__
    glewExperimental = GL_TRUE;
    GLenum err = glewInit();
    if (GLEW_OK != err)
        qDebug() << glewGetErrorString(err);
#endif

    this->Dataset("/home/sugeerth/Visual_REcognition/VolumeRayCasting/SampleVolume.raw","32","32","32");

}

void GLWidget::Dataset(string Path, string X, string Y, string Z)

{
        cout<<"IN Dataset"<<endl;
        glClearColor(1.0, 1.0, 1.0, 0.0);
        glEnable(GL_BLEND);
        glBlendEquation(GL_FUNC_ADD);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glEnable(GL_CULL_FACE);
        glCullFace(GL_FRONT);
        glDisable(GL_DEPTH_TEST);
        glColorMask(true, true, true, true);
        glDepthMask(true);
//        glutWireCube(1.0);

        // initialize transformation
        cout<<"initializing GL"<<endl;

        rotation = Mat3f::identity();
        translation = Vec3f(0.0f, 0.0f, -2.0f);
        // load sample data volume
        volumeDim.x = stoi(X);
        volumeDim.y = stoi(Y);
        volumeDim.z = stoi(Z);
        int volumeSize = volumeDim.x * volumeDim.y * volumeDim.z;
        std::vector<unsigned char> volumeData;
        volumeData.resize(volumeSize);
        std::ifstream ifs(Path, std::ios::binary);
        if(!ifs.is_open())
        {
            qDebug() << "Failed to open sample volume!";
            close();
        }

        ifs.read(reinterpret_cast<char *>(&volumeData.front()), volumeSize * sizeof(unsigned char));
        ifs.close();

        // prepare transfer function data
        std::vector<Vec4f> transferFuncData;
        transferFuncData.push_back(Vec4f(1.0f, 0.0f, 0.0f, 0.0f));
        transferFuncData.push_back(Vec4f(1.0f, 1.0f, 0.0f, 0.1f));
        transferFuncData.push_back(Vec4f(0.0f, 1.0f, 0.0f, 0.2f));
        transferFuncData.push_back(Vec4f(0.0f, 1.0f, 1.0f, 0.3f));
        transferFuncData.push_back(Vec4f(0.0f, 0.0f, 1.0f, 0.4f));
        transferFuncData.push_back(Vec4f(1.0f, 0.0f, 1.0f, 0.5f));

        // create OpenGL textures
        volumeTex = GLTexture::create();
        volumeTex->updateTexImage3D(GL_R8, volumeDim, GL_RED, GL_UNSIGNED_BYTE, &volumeData.front());

        transferFuncTex = GLTexture::create();
        transferFuncTex->updateTexImage2D(GL_RGBA32F, Vec2i(int(transferFuncData.size()), 1), GL_RGBA, GL_FLOAT, &transferFuncData.front());

        ////    GLuint g_tffTexObj;
        //    transferFuncTex = GLTexture::create();
        //    transferFuncTex->initTFF1DTex("tff.dat");
        // create full screen rectangle for volume ray-casting
        std::vector<Vec2f> rectVertices;
        rectVertices.push_back(Vec2f(0.0f, 0.0f));
        rectVertices.push_back(Vec2f(0.0f, 1.0f));
        rectVertices.push_back(Vec2f(1.0f, 1.0f));
        rectVertices.push_back(Vec2f(1.0f, 0.0f));
        rectVertexBuffer = GLArrayBuffer::create(GL_ARRAY_BUFFER);
        rectVertexBuffer->update(rectVertices.size() * sizeof(Vec2f), &rectVertices.front(), GL_STATIC_DRAW);
        rectVertexArray = GLVertexArray::create();

        Shininess = 80;
        Density = 1.0f;
        Brightness = 0.95f;
        SamplingRate = 0.005f;
        transferScale = 1.0f;
        DiffuseContribution = 0.65;
        SpecularContribution = 0.3;
        AmbienceCoefficient = 0.30f;
        transferOffset = 0.00f;
        Shininess = 80;

        // create OpenGL shaders
        volumeRayCastingProgram = GLShaderProgram::create("VolumeRayCasting.vert", "VolumeRayCasting.frag");
        if(volumeRayCastingProgram == NULL)
            close();

        // assign vertex buffer to the shader attribute input called "Vertex"
        volumeRayCastingProgram->setVertexAttribute("Vertex", rectVertexArray, rectVertexBuffer, 2, GL_FLOAT, false);
}

void GLWidget::resizeGL(int w, int h)
{
    glViewport(0, 0, w, h);
    projectionMatrix = Mat4f::perspective(Math::pi<float>() * 0.25f, float(w) / float(h), 0.01f, 10.0f);
}
void GLWidget::paintGL()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    getIntermediateValues();
    Vec3f volumeScale = Vec3f(volumeDim);
    volumeScale = volumeScale / volumeScale.norm();
    modelViewMatrix = Mat4f(rotation, translation);
    Mat4f transform = Mat4f::ortho(0, 1, 0, 1, -1, 1);
    Mat4f invModelView = modelViewMatrix.inverse();
    volumeRayCastingProgram->setUniform("volumeScale", volumeScale);
    volumeRayCastingProgram->setUniform("transform", transform);
    volumeRayCastingProgram->setUniform("invModelView", invModelView);
    volumeRayCastingProgram->setUniform("StepSize", StepSize);
    volumeRayCastingProgram->setUniform("Brightness", Brightness);
    volumeRayCastingProgram->setUniform("offset", offset);
    volumeRayCastingProgram->setUniform("SamplingRate", SamplingRate);
    volumeRayCastingProgram->setUniform("Density", Density);
    volumeRayCastingProgram->setUniform("transparency", transparency);
    volumeRayCastingProgram->setUniform("SpecularContribution", SpecularContribution);
    volumeRayCastingProgram->setUniform("AmbienceCoefficient", AmbienceCoefficient);
    volumeRayCastingProgram->setUniform("DiffuseContribution", DiffuseContribution);
    volumeRayCastingProgram->setUniform("Shininess", Shininess);
    volumeRayCastingProgram->setUniform("transferScale",transferScale);
    volumeRayCastingProgram->setUniform("transferOffset",transferOffset);
    volumeRayCastingProgram->setUniform("aspect", float(width()) / float(height()));
    volumeRayCastingProgram->setUniform("cotFOV", projectionMatrix.elem[1][1]);
    volumeRayCastingProgram->setTexture("volumeTex", volumeTex);
    volumeRayCastingProgram->setTexture("transferFuncTex", transferFuncTex);
    volumeRayCastingProgram->begin();
    rectVertexArray->drawArrays(GL_TRIANGLE_FAN, 4);
    volumeRayCastingProgram->end();
}

void GLWidget::getIntermediateValues()
{
//    cout<<"Updating";
    StepSize = 0.02;
    Brightness = 10;
}

void GLWidget::checkSnapshot()
{
     ofstream myfile;
     myfile.open ("Snapshot.txt",ios::app);
     myfile << "Configuration: "<<"SamplingRate: "<<endl<<SamplingRate<<endl<<"Density:"<<Density<<endl<<"Shininess:"<<Shininess<<endl<<"Density:"<<Density<<endl<<"Brightness:"<<Brightness<<endl<<"transferOffset:"<<transferOffset<<endl<<"transferScale"<<transferScale<<endl<<"DiffuseContribution"<<DiffuseContribution<<endl<<"AmbienceCoefficient"<<AmbienceCoefficient<<endl<<"SpecularContribution"<<SpecularContribution<<endl;
     myfile.close();
     cout<<"Writing configuration to Snapshot.txt"<<endl;
}
void GLWidget::checkAmbience(bool value)
{
    if (value == true){
        AmbienceCoefficientOld = AmbienceCoefficient;
        AmbienceCoefficient= 0;}
    else{
        AmbienceCoefficient= AmbienceCoefficientOld;
        }
    update();

}


void GLWidget::changeDataset(string Path,string X,string Y,string Z)
{
    cout<<"IN GLWIDGET"<<endl;
    cout<<"Performing now"<<endl;
    cout<<Path;
    this->Dataset(Path,X,Y,Z);
}

void GLWidget::checkDiffusion(bool value)
{
    if (value == true){
        DiffuseContributionOld = DiffuseContribution;
        DiffuseContribution = 0;}
    else{
        DiffuseContribution = DiffuseContributionOld;
        }
    update();
}
void GLWidget::checkSpecular(bool value)
{
    if (value == true){
        SpecularContributionOld = SpecularContribution;
        SpecularContribution = 0;}
    else{
        SpecularContribution = SpecularContributionOld;
        }
    update();
}
void GLWidget::changeShine(int value)
{
    Shininess = float(value);
    cout<<"Shininess"<<Shininess<<endl;
    update();
}

//Handling SLots from Transparency Sliders
void GLWidget::changeDensity(int value)
{
    Density = float(float(value)/100.0);
    cout<<"Density"<<Density<<endl;
    update();
}

void GLWidget::changeDiffuse(int value)
{
    DiffuseContribution = 0.65 + float(value)/1000.0;
    cout<<DiffuseContribution<<endl;
    update();
}
//void GLWidget::changeDataSet(char* value)
//{

//    cout<<value;
//}

void GLWidget::changeSampleRate(int value)
{
    SamplingRate = float(value)/1000.0f;
    cout<<SamplingRate<<endl;
    update();
}

void GLWidget::changeSpecular(int value)
{
    SpecularContribution= 0.30 + float(value)/1000.0;
    cout<<SpecularContribution<<endl;
    update();
}
//Actually this is change transfer Scale just a bit lazy
void GLWidget::changeTransparency(int value)
{
    transferScale = 1.00 + float(value)/100.0f;
    cout<<transferScale<<endl;
    update();
}

void GLWidget::changeTransferOffset(int value)
{
    transferOffset = float(value)/100.0f;
    cout<<transferOffset<<endl;
    update();
}
void GLWidget::changeBrighness(int value)
{
    Brightness = value/100;
    cout<<Brightness<<endl;
    update();
}

void GLWidget::changeAmbience(int value)
{
    AmbienceCoefficient= 0.30 + float(value)/1000.0;
    cout<<AmbienceCoefficient<<endl;
    update();
}

void GLWidget::mouseMoveEvent(QMouseEvent *event)
{
    QPointF pos = event->localPos();
    float dx = pos.x() - mousePos.x();
    float dy = pos.y() - mousePos.y();
    mousePos = pos;

    Qt::MouseButtons mouseButtons = event->buttons();

    if(mouseButtons & Qt::LeftButton)
    {
        rotation = Mat3f::fromAxisAngle(Vec3f::unitY(), dx * 0.005f) * rotation;
        rotation = Mat3f::fromAxisAngle(Vec3f::unitX(), dy * 0.005f) * rotation;
        rotation.orthonormalize();
    }

    if(mouseButtons & Qt::RightButton)
    {
        translation.z += dy * 0.005f;
        translation.z = clamp(translation.z, -9.0f, 1.0f);
    }

    if(mouseButtons & Qt::MidButton)
    {
        float scale = -std::min(translation.z, 0.0f) * 0.001f + 0.000025f;
        translation.x += dx * scale;
        translation.y -= dy * scale;
    }

    updateGL();
}

void GLWidget::mousePressEvent(QMouseEvent *event)
{
    mousePos = event->localPos();
}

void GLWidget::mouseReleaseEvent(QMouseEvent *event)
{
    mousePos = event->localPos();
}

void GLWidget::wheelEvent(QWheelEvent * event)
{
    QPoint numPixels = event->pixelDelta();
    QPoint numDegrees = event->angleDelta() / 8;
    float dx = 0.0f, dy = 0.0f;
    if(!numPixels.isNull())
    {
        dx = numPixels.x();
        dy = numPixels.y();
    }
    else if(!numDegrees.isNull())
    {
        dx = numDegrees.x() / 15;
        dy = numDegrees.y() / 15;
        dy = numDegrees.y() * -1;
    }

    Qt::KeyboardModifiers km = QApplication::keyboardModifiers();

    if(km & Qt::ControlModifier)
    {
        rotation = Mat3f::fromAxisAngle(Vec3f::unitY(), dx * 0.005f) * rotation;
        rotation = Mat3f::fromAxisAngle(Vec3f::unitX(), dy * 0.005f) * rotation;
    }
    else if(km & Qt::AltModifier)
    {
        float scale = -std::min(translation.z, 0.0f) * 0.001f + 0.000025f;
        translation.x += dx * scale;
        translation.y -= dy * scale;
    }
    else// if(km & Qt::ShiftModifier)
    {
        translation.z += dy * 0.005f;
        translation.z = clamp(translation.z, -9.0f, 1.0f);
    }

    updateGL();
}
