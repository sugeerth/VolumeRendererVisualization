#include "interactivetransferfunction.h"

InteractiveTransferFunction::InteractiveTransferFunction()
{
}
